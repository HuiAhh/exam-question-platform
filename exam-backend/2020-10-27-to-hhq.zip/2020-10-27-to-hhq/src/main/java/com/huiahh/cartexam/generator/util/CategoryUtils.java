package com.huiahh.cartexam.generator.util;

import com.huiahh.cartexam.generator.entity.Category;
import com.huiahh.cartexam.generator.entity.dto.CategoryDto;

import java.util.ArrayList;
import java.util.List;

public class CategoryUtils {

}
