package com.huiahh.cartexam.generator.repositories.elasticsearch;

import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

//interface QuestionRepository extends ElasticsearchRepository<Question,Integer> {
//}
